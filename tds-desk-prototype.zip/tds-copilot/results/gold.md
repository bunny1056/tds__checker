# Results: gold

```
{
  "mode": "gold",
  "model": null,
  "n": 15,
  "category_correct": 15,
  "tds_correct": 15,
  "route_correct": 15,
  "auto_posted": 11,
  "wrong_and_auto_posted": []
}
```

| Invoice | Categories (got / expected) | TDS got | TDS expected | Route (got / expected) | Why routed |
|---|---|---|---|---|---|
| INV01 | ['professional_fee'] / ['professional_fee'] | 35000 | 35000 | auto / auto |  |
| INV02 | ['contract_work'] / ['contract_work'] | 3600 | 3600 | auto / auto |  |
| INV03 | ['technical_fee'] / ['technical_fee'] | 1800 | 1800 | review / review | line 1: could also be 'contract_work' |
| INV04 | ['rent_land_building'] / ['rent_land_building'] | 12000 | 12000 | auto / auto |  |
| INV05 | ['rent_plant_machinery'] / ['rent_plant_machinery'] | 1500 | 1500 | auto / auto |  |
| INV06 | ['commission'] / ['commission'] | 920 | 920 | auto / auto |  |
| INV07 | ['professional_fee'] / ['professional_fee'] | 7000 | 7000 | auto / auto |  |
| INV08 | ['contract_work'] / ['contract_work'] | 0 | 0 | review / review | nil TDS relies on transporter declaration: confirm it is on file |
| INV09 | ['contract_work', 'rent_land_building'] / ['contract_work', 'rent_land_building'] | 10800 | 10800 | review / review | line 2: could also be 'contract_work' |
| INV10 | ['professional_fee'] / ['professional_fee'] | 12000 | 12000 | auto / auto |  |
| INV11 | ['goods_purchase'] / ['goods_purchase'] | 1600 | 1600 | auto / auto |  |
| INV12 | ['professional_fee', 'reimbursement'] / ['professional_fee', 'reimbursement'] | 18800 | 18800 | review / review | line 2: reimbursement included in base by default; confirm treatment |
| INV13 | ['professional_fee'] / ['professional_fee'] | 8500 | 8500 | auto / auto |  |
| INV14 | ['contract_work', 'contract_work'] / ['contract_work', 'contract_work'] | 10000 | 10000 | auto / auto |  |
| INV15 | ['professional_fee'] / ['professional_fee'] | 8000 | 8000 | auto / auto |  |
