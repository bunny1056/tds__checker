# Results: baseline

```
{
  "mode": "baseline",
  "model": null,
  "n": 15,
  "category_correct": 10,
  "tds_correct": 9,
  "route_correct": 10,
  "auto_posted": 10,
  "wrong_and_auto_posted": [
    "INV08",
    "INV15"
  ]
}
```

| Invoice | Categories (got / expected) | TDS got | TDS expected | Route (got / expected) | Why routed |
|---|---|---|---|---|---|
| INV01 | ['professional_fee'] / ['professional_fee'] | 35000 | 35000 | auto / auto |  |
| INV02 | ['contract_work'] / ['contract_work'] | 3600 | 3600 | auto / auto |  |
| INV03 | ['technical_fee'] / ['technical_fee'] | 1800 | 1800 | auto / review |  |
| INV04 | ['rent_land_building'] / ['rent_land_building'] | 12000 | 12000 | auto / auto |  |
| INV05 | ['unknown'] / ['rent_plant_machinery'] | 0 | 1500 | review / auto | line 1: category 'unknown' needs a person |
| INV06 | ['commission'] / ['commission'] | 920 | 920 | auto / auto |  |
| INV07 | ['professional_fee'] / ['professional_fee'] | 7000 | 7000 | auto / auto |  |
| INV08 | ['contract_work'] / ['contract_work'] | 1400 | 0 | auto / review |  |
| INV09 | ['unknown', 'unknown'] / ['contract_work', 'rent_land_building'] | 0 | 10800 | review / review | line 1: category 'unknown' needs a person; line 2: category 'unknown' needs a person |
| INV10 | ['professional_fee'] / ['professional_fee'] | 12000 | 12000 | auto / auto |  |
| INV11 | ['goods_purchase'] / ['goods_purchase'] | 1600 | 1600 | auto / auto |  |
| INV12 | ['professional_fee', 'reimbursement'] / ['professional_fee', 'reimbursement'] | 18800 | 18800 | review / review | line 2: reimbursement included in base by default; confirm treatment |
| INV13 | ['technical_fee'] / ['professional_fee'] | 1700 | 8500 | review / auto | line 1: 'technical_fee' conflicts with trap T1_TECH_CONSULTANCY (Notified professions under s.44AA (1961 Act) read with s.194J Explanation) |
| INV14 | ['rent_land_building', 'commission'] / ['contract_work', 'contract_work'] | 44000 | 10000 | review / auto | line 2: 'commission' conflicts with trap T2_AD_AGENCY (CBDT Circular No. 715 (1995)) |
| INV15 | ['technical_fee'] / ['professional_fee'] | 1600 | 8000 | auto / auto |  |
