"""Run the 15 synthetic invoices through one mode and write a report.

  python run_eval.py --mode gold       # engine + verifier + router with hand-labelled categories
  python run_eval.py --mode baseline   # keyword classifier (non-AI) + same engine
  python run_eval.py --mode llm        # LLM classifier + same engine   (needs OPENROUTER_API_KEY)
  python run_eval.py --mode llm_direct # LLM asked for the TDS amount directly (rejected design)
"""
import argparse
import json
import time
from pathlib import Path

from tds.classifiers import DEFAULT_MODEL, llm_direct
from tds.engine import load_rules
from tds.pipeline import process
from tds.preprocess import preprocess

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["gold", "baseline", "llm", "llm_direct"], default="gold")
    ap.add_argument("--sleep", type=float, default=0.0, help="seconds between LLM calls (free-tier rate limits)")
    a = ap.parse_args()

    gold = json.loads((DATA / "gold.json").read_text())
    ledger = json.loads((DATA / "ledger.json").read_text())
    buyer = json.loads((DATA / "buyer.json").read_text())
    rules = load_rules()
    rows, records = [], {}

    for cid, g in gold.items():
        text = (DATA / "invoices" / f"{cid}.txt").read_text()
        if a.mode == "llm_direct":
            pre = preprocess(text)
            note = json.dumps(ledger.get("2026-27", {}).get(pre["pan"] or "", {})) or "none"
            try:
                out = llm_direct(text, note)
                got = int(round(float(out.get("total_tds", -1))))
            except Exception as e:  # noqa: BLE001
                out, got = {"error": str(e)}, None
            rows.append({"id": cid, "tds_ok": got == g["expected_tds"], "got_tds": got, "exp_tds": g["expected_tds"],
                         "route": "auto", "route_ok": g["expected_route"] == "auto", "cat_ok": None, "detail": out})
            records[cid] = out
            time.sleep(a.sleep)
            continue

        pre = preprocess(text)
        gold_lines = None
        if a.mode == "gold":
            desc = {p["no"]: p for p in pre["lines"]}
            gold_lines = [{**gl, "description": desc[gl["no"]]["description"], "amount": desc[gl["no"]]["amount"],
                           "evidence": desc[gl["no"]]["description"], "confidence": 1.0} for gl in g["lines"]]
        try:
            rec = process(text, ledger, buyer, rules, classifier=a.mode, gold_lines=gold_lines, gold_flags=g["flags"])
        except Exception as e:  # noqa: BLE001
            rows.append({"id": cid, "error": str(e), "tds_ok": False, "route_ok": False, "cat_ok": False,
                         "got_tds": None, "exp_tds": g["expected_tds"], "route": "error"})
            continue
        got_cats = [ln["category"] for ln in rec["facts"]["lines"]]
        exp_cats = [ln["category"] for ln in g["lines"]]
        got_tds = rec["result"]["total_tds"] if rec["result"] else None
        rows.append({
            "id": cid, "cat_ok": got_cats == exp_cats, "got_cats": got_cats, "exp_cats": exp_cats,
            "got_tds": got_tds, "exp_tds": g["expected_tds"], "tds_ok": got_tds == g["expected_tds"],
            "route": rec["decision"]["route"], "exp_route": g["expected_route"],
            "route_ok": rec["decision"]["route"] == g["expected_route"],
            "reasons": rec["decision"]["reasons"],
            "citations": [i["citation"] for i in rec["result"]["items"]] if rec["result"] else [],
        })
        records[cid] = rec
        time.sleep(a.sleep)

    n = len(rows)
    wrong_auto = [r for r in rows if r["route"] == "auto" and not r["tds_ok"]]
    summary = {
        "mode": a.mode, "model": DEFAULT_MODEL if a.mode.startswith("llm") else None, "n": n,
        "category_correct": sum(1 for r in rows if r.get("cat_ok")),
        "tds_correct": sum(1 for r in rows if r["tds_ok"]),
        "route_correct": sum(1 for r in rows if r["route_ok"]),
        "auto_posted": sum(1 for r in rows if r["route"] == "auto"),
        "wrong_and_auto_posted": [r["id"] for r in wrong_auto],
    }
    out_dir = ROOT / "results"
    out_dir.mkdir(exist_ok=True)
    (out_dir / f"{a.mode}.json").write_text(json.dumps({"summary": summary, "rows": rows, "records": records}, indent=2, default=str))

    md = [f"# Results: {a.mode}", "", "```", json.dumps(summary, indent=2), "```", "",
          "| Invoice | Categories (got / expected) | TDS got | TDS expected | Route (got / expected) | Why routed |",
          "|---|---|---|---|---|---|"]
    for r in rows:
        cats = f"{r.get('got_cats', '-')} / {r.get('exp_cats', '-')}"
        md.append(f"| {r['id']} | {cats} | {r['got_tds']} | {r['exp_tds']} | {r['route']} / {r.get('exp_route', '-')} | "
                  f"{'; '.join(r.get('reasons', []))[:160]} |")
    (out_dir / f"{a.mode}.md").write_text("\n".join(md) + "\n")
    print(json.dumps(summary, indent=2))
    for r in rows:
        mark = "OK " if (r["tds_ok"] and r["route_ok"]) else "XX "
        print(mark, r["id"], r.get("got_cats"), r["got_tds"], "exp", r["exp_tds"], r["route"], "|", "; ".join(r.get("reasons", []))[:140])


if __name__ == "__main__":
    main()
