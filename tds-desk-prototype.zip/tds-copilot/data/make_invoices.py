"""Generates the 15 SYNTHETIC test invoices and their hand-labelled expected answers.

All vendors, PANs, GSTINs and amounts are invented. PANs use the 'ZZZ' prefix so
they are obviously fictitious, but keep the real format (4th character = holder status).
Expected TDS values in GOLD were computed by hand (working shown in 'why'), not by the engine.
Buyer: Kaveri Precision Components Pvt Ltd (fictional), Chennai, previous-FY turnover Rs 42 crore.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUYER = "Kaveri Precision Components Pvt Ltd, Plot 7, Ambattur Industrial Estate, Chennai 600058"


def gstin(pan):
    return f"33{pan}1Z5"


def invoice(supplier, pan, inv_no, dt, lines, gst=True, extra="", pan_line=True):
    taxable = sum(a for _, a in lines)
    rows = "\n".join(f"{i}. {d} | {a:,.2f}" for i, (d, a) in enumerate(lines, 1))
    head = [f"TAX INVOICE" if gst else "INVOICE", f"Supplier: {supplier}"]
    if gst and pan:
        head.append(f"GSTIN: {gstin(pan)}")
    head.append(f"PAN: {pan}" if (pan and pan_line) else "PAN: Not provided")
    head += [f"Invoice No: {inv_no}    Date: {dt}", f"Bill To: {BUYER}", "",
             "Particulars | Amount (INR)", rows, f"Taxable value | {taxable:,.2f}"]
    total = taxable
    if gst:
        cg = round(taxable * 0.09, 2)
        head += [f"CGST @ 9% : {cg:,.2f}", f"SGST @ 9% : {cg:,.2f}"]
        total += 2 * cg
    head.append(f"Invoice total: {total:,.2f}")
    if extra:
        head += ["", extra]
    return "\n".join(head) + "\n"


# (id, invoice kwargs, gold lines [(category, alt)], flags, expected_tds, expected_route, why)
CASES = [
    ("INV01", dict(supplier="Raman & Iyer, Chartered Accountants", pan="ZZZFR0001R", inv_no="RI/26-27/118", dt="12-10-2026",
        lines=[("Statutory audit of financial statements for FY 2025-26", 350000)]),
     [("professional_fee", None)], [], 35000, "auto", "Professional 10% x 3,50,000 (GST excluded)."),
    ("INV02", dict(supplier="BrightNest Facility Services Pvt Ltd", pan="ZZZCB0002B", inv_no="BN/1043", dt="31-10-2026",
        lines=[("Housekeeping and manpower supply at Ambattur plant, October 2026", 180000)]),
     [("contract_work", None)], [], 3600, "auto", "Contract, company payee 2% x 1,80,000 (single bill > 30,000)."),
    ("INV03", dict(supplier="Codeweave Infotech LLP", pan="ZZZFC0003C", inv_no="CW-2210", dt="02-11-2026",
        lines=[("Remote IT helpdesk support and server monitoring, October 2026", 90000)]),
     [("technical_fee", "contract_work")], [], 1800, "review", "Technical 2% x 90,000; genuinely arguable as contract (also 2% for a firm) -> review."),
    ("INV04", dict(supplier="Lakshmi Ammal", pan="ZZZPL0004L", inv_no="R-11/2026", dt="01-11-2026", gst=False,
        lines=[("Rent for office premises, 2nd floor, Anna Nagar, November 2026", 120000)]),
     [("rent_land_building", None)], [], 12000, "auto", "Rent building 10% x 1,20,000 (month > 50,000)."),
    ("INV05", dict(supplier="Sri Murugan Gensets", pan="ZZZPS0005S", inv_no="SMG/77", dt="31-10-2026",
        lines=[("Hire charges - 250 kVA DG set (without operator), October 2026", 75000)]),
     [("rent_plant_machinery", None)], [], 1500, "auto", "Hire of machinery = rent of plant 2% x 75,000 (month > 50,000)."),
    ("INV06", dict(supplier="Velan Trade Links", pan="ZZZPV0006V", inv_no="VTL-09", dt="05-10-2026", gst=False,
        lines=[("Commission @2% on sales procured, Jul-Sep 2026", 46000)]),
     [("commission", None)], [], 920, "auto", "Commission 2% x 46,000 (FY aggregate > 20,000)."),
    ("INV07", dict(supplier="Ar. Meera Subramanian, Architect", pan="ZZZPM0007M", inv_no="MS/26/14", dt="20-10-2026", gst=False,
        lines=[("Architectural drawings for factory extension, stage 2", 40000)]),
     [("professional_fee", None)], [], 7000, "auto", "Ledger: 30,000 paid earlier, no TDS. Aggregate 70,000 > 50,000 -> 10% x 70,000 (catch-up)."),
    ("INV08", dict(supplier="Kongu Roadways", pan="ZZZPK0008K", inv_no="KR/552", dt="28-10-2026", gst=False,
        lines=[("Freight - transport of finished goods Chennai to Pune, 6 trips", 140000)],
        extra="Declaration: We own 6 goods carriages and have not owned more than ten goods carriages at any time during the year. PAN furnished above."),
     [("contract_work", None)], ["transporter_declaration"], 0, "review", "Transport is contract work, but declaration (<=10 carriages + PAN) -> nil; confirm declaration on file."),
    ("INV09", dict(supplier="Festivo Events Pvt Ltd", pan="ZZZCF0009F", inv_no="FE/2026/301", dt="15-10-2026",
        lines=[("Event management services for annual day (stage, sound, decor, coordination)", 240000),
               ("Banquet hall hire for one day", 60000)]),
     [("contract_work", None), ("rent_land_building", "contract_work")], [], 10800, "review", "Contract 2% x 2,40,000 = 4,800; hall rent 10% x 60,000 = 6,000. Hall could be part of the contract -> review."),
    ("INV10", dict(supplier="Adv. S. Krishnan", pan=None, inv_no="SK/41", dt="09-10-2026", gst=False,
        lines=[("Legal opinion on supply contract dispute with distributor", 60000)]),
     [("professional_fee", None)], [], 12000, "auto", "Professional, no PAN -> 20% x 60,000."),
    ("INV11", dict(supplier="Deccan Alloys Pvt Ltd", pan="ZZZCD0011D", inv_no="DA/INV/8812", dt="22-10-2026",
        lines=[("Supply of aluminium ingots, 12 MT", 2600000)]),
     [("goods_purchase", None)], [], 1600, "auto", "Ledger: 40 lakh bought earlier. 66 lakh total; 0.1% on 16 lakh above 50 lakh."),
    ("INV12", dict(supplier="Northstar Advisory LLP", pan="ZZZFN0012N", inv_no="NSA-118", dt="30-10-2026",
        lines=[("Professional fee - market entry study for Gujarat", 150000),
               ("Reimbursement of travel and hotel expenses (actuals, bills attached)", 38000)]),
     [("professional_fee", None), ("reimbursement", None)], [], 18800, "review", "10% on 1,88,000 incl. reimbursement (conservative); treatment of reimbursement needs a person."),
    ("INV13", dict(supplier="Prakash Engineering Consultants", pan="ZZZPP0013P", inv_no="PEC/26/7", dt="18-10-2026", gst=False,
        lines=[("Technical consultancy - vibration analysis of CNC spindle and recommendations", 85000)]),
     [("professional_fee", None)], [], 8500, "auto", "Technical consultancy is a notified profession -> 10% x 85,000 (not 2%)."),
    ("INV14", dict(supplier="Spectra Ads & Media Pvt Ltd", pan="ZZZCS0014S", inv_no="SAM/1907", dt="25-10-2026",
        lines=[("Release of print advertisements in regional dailies (media cost)", 425000),
               ("Agency commission @15%", 75000)]),
     [("contract_work", None), ("contract_work", None)], [], 10000, "auto", "Advertising agency: whole bill is contract 2% x 5,00,000; no commission TDS (CBDT Circular 715)."),
    ("INV15", dict(supplier="Raman & Iyer, Chartered Accountants", pan="ZZZFR0001R", inv_no="RI/25-26/902", dt="20-03-2026",
        lines=[("Tax advisory and return filing support, FY 2025-26", 80000)]),
     [("professional_fee", None)], [], 8000, "auto", "Dated March 2026 -> 1961 Act rule set, cite 194J(b): 10% x 80,000."),
]

LEDGER = {  # earlier payments this FY with no TDS deducted
    "2026-27": {
        "ZZZPM0007M": {"PROF": {"paid": 30000, "deducted_base": 0}},
        "ZZZCD0011D": {"GOODS": {"paid": 4000000, "deducted_base": 0}},
    }
}
BUYER_PROFILE = {"name": BUYER, "turnover_prev_fy": 420000000}


def main():
    inv_dir = HERE / "invoices"
    inv_dir.mkdir(exist_ok=True)
    gold = {}
    for cid, kw, lines, flags, tds, route, why in CASES:
        (inv_dir / f"{cid}.txt").write_text(invoice(**kw))
        gold[cid] = {"lines": [{"no": i, "category": c, "alt_category": a} for i, (c, a) in enumerate(lines, 1)],
                     "flags": flags, "expected_tds": tds, "expected_route": route, "why": why, "synthetic": True}
    (HERE / "gold.json").write_text(json.dumps(gold, indent=2))
    (HERE / "ledger.json").write_text(json.dumps(LEDGER, indent=2))
    (HERE / "buyer.json").write_text(json.dumps(BUYER_PROFILE, indent=2))
    print(f"wrote {len(CASES)} invoices")


if __name__ == "__main__":
    main()
