"""Deterministic pre-processing. Everything here is exact and auditable; no AI.

Facts that can be read mechanically are never left to the language model:
PAN, payee type (from the PAN's 4th character), GSTIN, invoice date,
whether GST is shown separately, and the numbered line items with amounts.
"""
import re
from datetime import date

PAN_RE = re.compile(r"\b([A-Z]{3}[PCHFATBLJG][A-Z][0-9]{4}[A-Z])\b")
GSTIN_RE = re.compile(r"\b[0-9]{2}([A-Z]{5}[0-9]{4}[A-Z])[0-9A-Z]Z[0-9A-Z]\b")
DATE_RE = re.compile(r"Date:\s*(\d{2})-(\d{2})-(\d{4})")
GST_RE = re.compile(r"\b(CGST|SGST|IGST|UTGST)\b")
LINE_RE = re.compile(r"^\s*(\d+)\.\s*(.+?)\s*\|\s*([\d,]+(?:\.\d+)?)\s*$", re.M)

# 4th character of a PAN encodes the holder's status (Income Tax Department convention).
PAN_STATUS = {
    "P": "individual", "H": "huf", "C": "company", "F": "firm",
    "A": "aop", "T": "trust", "B": "boi", "L": "local_authority",
    "J": "artificial_person", "G": "government",
}


def parse_amount(s: str) -> float:
    return float(s.replace(",", ""))


def preprocess(text: str) -> dict:
    pans = PAN_RE.findall(text)
    gstin_pans = GSTIN_RE.findall(text)
    pan = pans[0] if pans else (gstin_pans[0] if gstin_pans else None)
    issues = []
    if pans and gstin_pans and pans[0] != gstin_pans[0]:
        issues.append(f"PAN {pans[0]} does not match PAN embedded in GSTIN {gstin_pans[0]}")
    m = DATE_RE.search(text)
    inv_date = date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat() if m else None
    if not inv_date:
        issues.append("invoice date not found")
    lines = [
        {"no": int(n), "description": d.strip(), "amount": parse_amount(a)}
        for n, d, a in LINE_RE.findall(text)
    ]
    if not lines:
        issues.append("no line items parsed")
    return {
        "pan": pan,
        "pan_present": pan is not None,
        "payee_type": PAN_STATUS.get(pan[3]) if pan else None,
        "invoice_date": inv_date,
        "gst_separately_shown": bool(GST_RE.search(text)),
        "lines": lines,
        "issues": issues,
    }
