"""End-to-end: invoice text -> deterministic pre-processing -> classifier ->
verification -> deterministic engine -> routing. Returns one auditable record."""
from .classifiers import classify_baseline, classify_llm
from .engine import compute
from .preprocess import preprocess
from .verify_route import route, verify


def build_facts(pre, cls, vendor_id):
    return {
        "vendor_id": vendor_id,
        "invoice_date": pre["invoice_date"],
        "payee_type": pre["payee_type"],
        "pan_present": pre["pan_present"],
        "gst_separately_shown": pre["gst_separately_shown"],
        "lines": cls["lines"],
        "flags": cls.get("flags", []),
    }


def process(text, ledger, buyer, rules, classifier="baseline", gold_lines=None, gold_flags=None):
    pre = preprocess(text)
    if classifier == "gold":
        cls = {"lines": gold_lines, "flags": gold_flags or []}
    elif classifier == "baseline":
        cls = classify_baseline(text, pre)
    elif classifier == "llm":
        cls = classify_llm(text, pre)
    else:
        raise ValueError(classifier)
    vendor_id = pre["pan"] or "NO_PAN"
    errs = verify(text, pre, cls["lines"])
    facts = build_facts(pre, cls, vendor_id)
    result = compute(facts, ledger, buyer, rules) if not errs else None
    decision = route(text, pre, facts, result, errs)
    return {"pre": pre, "facts": facts, "result": result, "decision": decision,
            "raw": cls.get("_raw")}
