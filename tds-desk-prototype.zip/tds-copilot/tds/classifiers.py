"""Line classifiers. Each returns {'lines': [...], 'flags': [...]}.

baseline  - keyword rules, the non-AI approach a finance team might write first.
llm       - an LLM via OpenRouter that ONLY classifies lines and quotes evidence.
            It never sees a rate, threshold or ledger and never outputs a tax amount.
llm_direct- the design we rejected: ask the LLM for the TDS amount end-to-end.
            Kept only so the comparison can be run.
"""
import json
import os
import re
import urllib.request

from .categories import CATEGORIES, DEFINITIONS

# ---------------------------------------------------------------- baseline
KEYWORDS = [  # checked in this order, first match wins
    ("rent_land_building", ["rent", "lease", "premises"]),
    ("commission", ["commission", "brokerage"]),
    ("goods_purchase", ["supply of", "purchase of", "ingots", "material"]),
    ("technical_fee", ["technical", "support", "monitoring", "maintenance"]),
    ("professional_fee", ["audit", "legal", "consult", "architect", "advis", "professional fee"]),
    ("contract_work", ["contract", "labour", "manpower", "housekeeping", "transport", "freight", "catering", "advertis"]),
    ("reimbursement", ["reimbursement"]),
]


def classify_baseline(text: str, pre: dict) -> dict:
    out = []
    for p in pre["lines"]:
        d = p["description"].lower()
        cat = next((c for c, kws in KEYWORDS if any(k in d for k in kws)), "unknown")
        out.append({"no": p["no"], "description": p["description"], "amount": p["amount"],
                    "category": cat, "alt_category": None, "evidence": p["description"],
                    "confidence": 1.0})
    return {"lines": out, "flags": []}


# ---------------------------------------------------------------- LLM
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = os.environ.get("OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free")

CLASSIFY_PROMPT = """You classify the nature of payment on an Indian vendor invoice, line by line,
so that a separate, deterministic program can apply the tax-deduction (TDS) rules.
You do NOT compute tax, rates or thresholds. Do not mention any tax section.

Allowed categories (choose exactly one per line):
{definitions}

Rules:
- Return one entry per numbered line on the invoice, with the same line number and amount.
- "evidence" must be an exact, verbatim substring of the invoice text that justifies the category.
- If a qualified tax professional could reasonably classify the line differently, set
  "alt_category" to that category; otherwise null.
- "confidence" is your probability (0-1) that the category is correct.
- flags: include "transporter_declaration" ONLY if the invoice states the vendor owns ten or
  fewer goods carriages (a declaration); include nothing else.

Return ONLY JSON:
{{"lines":[{{"no":1,"amount":0,"category":"...","alt_category":null,"evidence":"...","confidence":0.0}}],"flags":[]}}

INVOICE:
<<<
{invoice}
>>>"""

DIRECT_PROMPT = """You are an Indian tax assistant. For the invoice below, received by a company
(previous-year turnover Rs 42 crore) on the invoice date shown, state the applicable TDS
section(s) and the total TDS to deduct in rupees. Vendor's earlier payments this financial year:
{ledger}
Return ONLY JSON: {{"sections":["..."],"total_tds":0}}

INVOICE:
<<<
{invoice}
>>>"""


def _call_openrouter(prompt: str, model: str = DEFAULT_MODEL) -> str:
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        raise RuntimeError("Set OPENROUTER_API_KEY to use the llm modes.")
    body = json.dumps({
        "model": model, "temperature": 0,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(OPENROUTER_URL, data=body, headers={
        "Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read())["choices"][0]["message"]["content"]


def _parse_json(s: str) -> dict:
    m = re.search(r"\{.*\}", s, re.S)
    if not m:
        raise ValueError("model returned no JSON")
    return json.loads(m.group(0))


def classify_llm(text: str, pre: dict) -> dict:
    raw = _call_openrouter(CLASSIFY_PROMPT.format(definitions=DEFINITIONS, invoice=text))
    data = _parse_json(raw)
    desc = {p["no"]: p["description"] for p in pre["lines"]}
    for ln in data.get("lines", []):
        ln.setdefault("alt_category", None)
        ln.setdefault("confidence", 0.0)
        ln["description"] = desc.get(ln.get("no"), "")
        if ln.get("category") not in CATEGORIES:
            ln["category"] = "unknown"
    data["flags"] = [f for f in data.get("flags", []) if f == "transporter_declaration"]
    data["_raw"] = raw
    return data


def llm_direct(text: str, ledger_note: str) -> dict:
    raw = _call_openrouter(DIRECT_PROMPT.format(invoice=text, ledger=ledger_note))
    data = _parse_json(raw)
    data["_raw"] = raw
    return data
