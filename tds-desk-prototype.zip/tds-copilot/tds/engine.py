"""Deterministic TDS calculator. No AI. Every number it outputs carries a trace.

Inputs: classified facts for one invoice, the vendor's year-to-date ledger,
the buyer profile, and the versioned rule tables. The rule set is picked by
the invoice date, so a FY 2025-26 invoice is cited under the 1961 Act and a
FY 2026-27 invoice under the 2025 Act.
"""
import json
from datetime import date
from pathlib import Path

from .categories import CATEGORIES

ROOT = Path(__file__).resolve().parent.parent


def load_rules(path=ROOT / "rules" / "tds_rules.json"):
    return json.loads(Path(path).read_text())


def ruleset_for(inv_date: str, rules: dict) -> dict:
    d = date.fromisoformat(inv_date)
    for rs in rules["rulesets"]:
        start = date.fromisoformat(rs["effective_from"])
        end = date.fromisoformat(rs["effective_to"]) if rs["effective_to"] else date.max
        if start <= d <= end:
            return rs
    raise ValueError(f"No rule set covers invoice date {inv_date}")


def fy_of(inv_date: str) -> str:
    d = date.fromisoformat(inv_date)
    y = d.year if d.month >= 4 else d.year - 1
    return f"{y}-{str(y + 1)[-2:]}"


def _round_rupee(x: float) -> int:
    # Tax is rounded to the nearest rupee.
    return int(x + 0.5)


def group_lines(lines):
    """Sum line amounts per rule. Reimbursements join the invoice's main category."""
    groups, reimb = {}, 0.0
    for ln in lines:
        rule = CATEGORIES.get(ln["category"])
        if ln["category"] == "reimbursement":
            reimb += ln["amount"]
        elif rule:
            groups[rule] = groups.get(rule, 0.0) + ln["amount"]
    if reimb and groups:
        main = max(groups, key=groups.get)
        groups[main] += reimb
    return groups, reimb


def compute(facts: dict, ledger: dict, buyer: dict, rules: dict) -> dict:
    rs = ruleset_for(facts["invoice_date"], rules)
    fy = fy_of(facts["invoice_date"])
    vendor_ledger = ledger.get(fy, {}).get(facts.get("vendor_id") or "", {})
    groups, reimb = group_lines(facts["lines"])
    flags = set(facts.get("flags", []))
    out = {"ruleset": rs["id"], "act": rs["act"], "fy": fy, "items": [], "total_tds": 0,
           "gst_excluded": facts["gst_separately_shown"]}

    for rule_id, amount in groups.items():
        r = rs["rules"][rule_id]
        prior = vendor_ledger.get(rule_id, {"paid": 0, "deducted_base": 0})
        undeducted_prior = prior["paid"] - prior["deducted_base"]
        payee = facts.get("payee_type") or "unknown"
        rate = r["rates"].get(payee, r["rates"]["default"])
        notes = []
        if not facts["pan_present"]:
            rate = max(rate, r["no_pan_rate"])
            notes.append(f"No PAN: higher rate {r['no_pan_rate']}% applied ({rs['no_pan_ref']}).")

        th, base = r["threshold"], 0.0
        if th["type"] == "single_or_aggregate":
            agg = prior["paid"] + amount
            if agg > th["aggregate"]:
                base = amount + undeducted_prior
                notes.append(f"FY aggregate {agg:,.0f} > {th['aggregate']:,}; TDS on this bill plus {undeducted_prior:,.0f} earlier undeducted.")
            elif amount > th["single"]:
                base = amount
                notes.append(f"Single bill {amount:,.0f} > {th['single']:,}.")
            else:
                notes.append("Below single and aggregate thresholds.")
        elif th["type"] == "aggregate":
            agg = prior["paid"] + amount
            if agg > th["limit"]:
                base = amount + undeducted_prior
                notes.append(f"FY aggregate {agg:,.0f} > {th['limit']:,}" + (f"; includes {undeducted_prior:,.0f} earlier undeducted." if undeducted_prior else "."))
            else:
                notes.append(f"FY aggregate {agg:,.0f} not above {th['limit']:,}.")
        elif th["type"] == "per_month":
            if amount > th["limit"]:
                base = amount
                notes.append(f"Rent for the month {amount:,.0f} > {th['limit']:,}.")
            else:
                notes.append(f"Rent for the month not above {th['limit']:,}.")
        elif th["type"] == "excess_over":
            if buyer["turnover_prev_fy"] <= th["buyer_turnover_min"]:
                notes.append("Buyer turnover not above the limit; provision does not apply.")
            else:
                before = max(0.0, prior["paid"] - th["limit"])
                after = max(0.0, prior["paid"] + amount - th["limit"])
                base = after - before
                notes.append(f"FY purchases {prior['paid'] + amount:,.0f}; TDS only on amount above {th['limit']:,}.")

        if rule_id == "CONTRACT" and "transporter_declaration" in flags:
            base = 0.0
            notes.append("Transporter declaration (<=10 goods carriages, PAN furnished) claimed: nil TDS, subject to declaration on file.")

        tds = _round_rupee(base * rate / 100)
        out["items"].append({
            "rule_id": rule_id, "citation": r["citation"], "nature": r["nature"],
            "old_ref": r.get("old_ref"), "amount": amount, "base": base,
            "rate_pct": rate, "tds": tds, "notes": notes,
        })
        out["total_tds"] += tds

    if reimb:
        out["reimbursement_included"] = reimb
    return out
