"""Checks on the classifier's output, and the decision to auto-post or send to a human.

The classifier is the only probabilistic part. These checks are deterministic:
  * every line it returns must match a line parsed from the invoice, amount for amount;
  * every evidence quote must appear verbatim in the invoice;
  * categories must come from the closed set;
  * known traps (glossary) must not be contradicted.
Anything that fails, or that is uncertain, goes to review with a stated reason.
"""
import json
import re
from pathlib import Path

from .categories import CATEGORIES

ROOT = Path(__file__).resolve().parent.parent
GLOSSARY = json.loads((ROOT / "rules" / "glossary.json").read_text())["traps"]

CONF_MIN = 0.75
MATERIALITY_TDS = 50000  # four-eyes review above this TDS amount per invoice


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.lower()).strip()


def verify(text: str, pre: dict, lines: list) -> list:
    errs = []
    ntext = _norm(text)
    parsed = {p["no"]: p for p in pre["lines"]}
    if len(lines) != len(parsed):
        errs.append(f"classifier returned {len(lines)} lines, invoice has {len(parsed)}")
    for ln in lines:
        p = parsed.get(ln.get("no"))
        if not p:
            errs.append(f"line {ln.get('no')} not on invoice")
            continue
        if abs(p["amount"] - float(ln.get("amount", -1))) > 0.5:
            errs.append(f"line {ln['no']}: amount {ln.get('amount')} != invoice {p['amount']}")
        if ln.get("category") not in CATEGORIES:
            errs.append(f"line {ln['no']}: category '{ln.get('category')}' not allowed")
        ev = ln.get("evidence") or ""
        if ev and _norm(ev) not in ntext:
            errs.append(f"line {ln['no']}: evidence quote not found in invoice")
        if not ev:
            errs.append(f"line {ln['no']}: no evidence quote")
    return errs


def glossary_conflicts(text: str, lines: list) -> list:
    hits, ntext = [], _norm(text)
    for t in GLOSSARY:
        if not t.get("pattern"):
            continue
        for ln in lines:
            scope = ntext if "applies_when_category_is" in t else _norm(ln.get("description", ""))
            if t["pattern"] in scope:
                wrong = t.get("applies_when_category_is")
                cat = ln.get("category")
                if (wrong and cat in wrong) or (not wrong and cat != t["expected_category"]):
                    hits.append(f"line {ln['no']}: '{cat}' conflicts with trap {t['id']} ({t['source']})")
    return hits


def route(text, pre, facts, result, verify_errs) -> dict:
    reasons = list(verify_errs) + list(pre["issues"])
    reasons += glossary_conflicts(text, facts["lines"])
    for ln in facts["lines"]:
        if ln.get("confidence", 1.0) < CONF_MIN:
            reasons.append(f"line {ln['no']}: low confidence {ln['confidence']}")
        if ln.get("alt_category"):
            reasons.append(f"line {ln['no']}: could also be '{ln['alt_category']}'")
        if ln["category"] in ("unknown", "no_tds"):
            reasons.append(f"line {ln['no']}: category '{ln['category']}' needs a person")
        if ln["category"] == "reimbursement":
            reasons.append(f"line {ln['no']}: reimbursement included in base by default; confirm treatment")
    if "transporter_declaration" in facts.get("flags", []):
        reasons.append("nil TDS relies on transporter declaration: confirm it is on file")
    if result and result["total_tds"] > MATERIALITY_TDS:
        reasons.append(f"TDS {result['total_tds']:,} above materiality {MATERIALITY_TDS:,}")
    return {"route": "review" if reasons else "auto", "reasons": reasons}
