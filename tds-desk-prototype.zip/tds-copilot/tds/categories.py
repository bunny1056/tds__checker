"""Closed set of payment categories the classifier may choose from, and their rule mapping."""

CATEGORIES = {
    "contract_work": "CONTRACT",
    "professional_fee": "PROF",
    "technical_fee": "TECH",
    "commission": "COMM",
    "rent_land_building": "RENT_LB",
    "rent_plant_machinery": "RENT_PM",
    "goods_purchase": "GOODS",
    "reimbursement": None,   # attached to the invoice's main category (conservative policy)
    "no_tds": None,          # e.g. a payment type outside these rules; always reviewed
    "unknown": None,
}

DEFINITIONS = """
contract_work: carrying out any work under a contract, including supply of labour/manpower,
  housekeeping, security, transport of goods, catering, event execution, advertising
  (including any 'agency commission' billed by an advertising agency), manufacturing to
  the buyer's specification using the buyer's material.
professional_fee: legal, medical, engineering, architectural, accountancy/audit, tax
  advisory, technical consultancy, interior decoration, advertising *profession* services,
  and other notified professions; also management/business consultancy reports.
technical_fee: managerial, technical or consultancy SERVICES that are not a profession,
  e.g. IT helpdesk, server monitoring, software support, calibration done as a service.
commission: commission or brokerage for buying/selling goods or services on the payer's
  behalf (NOT an advertising agency's commission).
rent_land_building: rent/hire for land, building, office, warehouse, hall, furniture, fittings.
rent_plant_machinery: rent/hire for plant, machinery, equipment, vehicles (without a
  contract to perform work), generators, cranes.
goods_purchase: purchase of goods/materials.
reimbursement: reimbursement of out-of-pocket expenses billed on the same invoice.
no_tds: a line that is clearly outside all of the above.
unknown: cannot tell from the invoice text.
""".strip()
